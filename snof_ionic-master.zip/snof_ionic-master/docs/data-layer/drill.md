drill
----------

{
	"id": "drill-1",
	"name": "Linking Wedge Turns in a Fall Line",
	"difficulty": 1,
	"description": "Linking Wedge Desc...",
	"terrain": "Beginner slope",
	"variations": "Variations ... ectetur est et pellentesque."
}


UNPACK method (called when drill is loaded from DB or REST API):
* LocalDataServiceProvider._unpackDrill
-
PACK method (called before drill is saved to DB or REST API):
* LocalDataServiceProvider._packDrill
