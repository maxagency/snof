image
-----------

{
	"id": "image-1",
	"base64": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGcAAABoCAYAAADsF+4sAAAZ8GlDQ1BJQ0MgUHJvZmlsZQAAWIXtWQdXU...3n4ghziPn+3k2vV/UMt/z+EfnU0zCK8SwAAAABJRU5ErkJggg=="
}