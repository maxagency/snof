program
----------

{
	"id": "program-1",
	"phase": "phase-1",
	"location": "location-1",
	"description": "In this series we will focus on strength training for the Sun Valley competition next week",
	"sessions": ["session-1a","session-1b","session-1c"],
	"attendees": ["athlete-1","athlete-2","athlete-3","trainer-2"],
	"drills": ["drill-1","drill-2","drill-3","drill-4","drill-5"]
}


* LocalDataServiceProvider._unpackProgram
	- loads program.phase
	- loads program.sessions
	- loads program.attendees
	- loads program.drills





